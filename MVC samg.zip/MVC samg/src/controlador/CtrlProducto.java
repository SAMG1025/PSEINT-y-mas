
package controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.ConsultaProducto;
import modelo.producto;
import vista.frmProducto;

public class CtrlProducto implements ActionListener {
    private producto mod;
    private ConsultaProducto modC;
    private frmProducto frm;
    
    public CtrlProducto(producto mod, ConsultaProducto modC, frmProducto frm){
        this.mod = mod;
        this.modC = modC;
        this.frm = frm;
        this.frm.btnGuardar.addActionListener(this);
    }
   public void iniciar() {
    frm.setTitle("Estudiantes");
    frm.setLocationRelativeTo(null);
}
   @Override
   public void actionPerformed(ActionEvent e){
       if (e.getSource() == frm.btnGuardar){
           mod.setCodigo(frm.textCodigo.getText());
           mod.setApellidos(frm.textApellidos.getText());
           mod.setCargo(frm.textCargo.getText());
           
           if(modC.registrar(mod))
           {
               JOptionPane.showMessageDialog(null, "registro guardado");
           }else{
               JOptionPane.showMessageDialog(null, "No guardado");
           }
       }
   }
   
}
 