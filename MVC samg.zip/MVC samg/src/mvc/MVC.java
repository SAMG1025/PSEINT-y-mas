
package mvc;

import modelo.producto;
import modelo.ConsultaProducto;
import vista.frmProducto;
import controlador.CtrlProducto;

public class MVC {

   
    public static void main(String[] args) {
    producto mod = new producto();
    ConsultaProducto modC = new ConsultaProducto();
    frmProducto frm = new frmProducto();
    
    CtrlProducto ctrl = new CtrlProducto(mod, modC, frm);
    ctrl.iniciar();
    frm.setVisible(true);
    }
    
}
