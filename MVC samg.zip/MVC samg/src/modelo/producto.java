package modelo;

public class producto {
    private int id;
    private String Codigo;
    private String nombre;
    private String apellidos;
    private String cargo;
    private Double precio;
    private int cantidad;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String codigo) {
        this.Codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellidos() {
        return apellidos;
    }
    
     public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
      public String getCargo() {
        return cargo;
    }
    
     public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    

}
