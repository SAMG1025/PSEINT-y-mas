
package modelo;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class ConsultaProducto extends conexion{
    public boolean registrar(producto pro){
        PreparedStatement ps = null;
        Connection con = getConexion();
        
        String sql = "insert into estudiantes (Nombres,Apellidos,Cargo) values(?,?,?)";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, pro.getCodigo());
            ps.setString(2, pro.getApellidos());
            ps.setString(3, pro.getCargo());
            
            ps.execute();
            return true;
         }catch(SQLException e)
         {
             System.err.println(e);
                     return false;
         }finally{
            try{
                con.close();
            }catch(SQLException e){
             System.err.println(e);
        }
    }
    
  }
}
