package controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.ConsultaVehiculos;
import modelo.Vehiculos;
import vista.frmVehiculos;
public class CtrlVehiculos implements ActionListener {
    private Vehiculos mod;
    private ConsultaVehiculos modC;
    private frmVehiculos frm;
    
    public CtrlVehiculos(Vehiculos mod, ConsultaVehiculos modC, frmVehiculos frm){
        this.mod = mod;
        this.modC = modC;
        this.frm = frm;
        this.frm.btnGuardar.addActionListener(this);
    }
   public void iniciar() {
    frm.setTitle("vehiculos");
    frm.setLocationRelativeTo(null);
}
   @Override
   public void actionPerformed(ActionEvent e){
       if (e.getSource() == frm.btnGuardar){
           mod.setTipo_de_vehiculo(frm.textTipo_de_vehiculo.getText());
           mod.setPlaca(frm.textPlaca.getText());
           mod.setModelo(frm.textModelo.getText());
           
           if(modC.registrar(mod))
           {
               JOptionPane.showMessageDialog(null, "registro guardado");
           }else{
               JOptionPane.showMessageDialog(null, "No guardado");
           }
       }
   }
   
}
