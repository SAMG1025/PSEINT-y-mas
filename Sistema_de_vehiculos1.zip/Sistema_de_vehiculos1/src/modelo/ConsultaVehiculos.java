package modelo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelo.conexion;

public class ConsultaVehiculos extends conexion{
    public boolean registrar(Vehiculos pro){
        PreparedStatement ps = null;
        Connection con = getConexion();
        
        String sql = "insert into vehiculos (Tipo_de_vehiculo,Placa,Modelo) values(?,?,?)";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, pro.getTipo_de_vehiculo());
            ps.setString(2, pro.getPlaca());
            ps.setString(3, pro.getModelo());
            
            ps.execute();
            return true;
         }catch(SQLException e)
         {
             System.err.println(e);
                     return false;
         }finally{
            try{
                con.close();
            }catch(SQLException e){
             System.err.println(e);
        }
    }
    
  }
}