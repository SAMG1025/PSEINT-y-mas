package modelo;
public class Vehiculos {
     private int id;
    private String Tipo_de_vehiculo;
    private String Placa;
    private String Modelo;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo_de_vehiculo() {
        return Tipo_de_vehiculo;
    }

    public void setTipo_de_vehiculo(String Tipo_de_vehiculo) {
        this.Tipo_de_vehiculo = Tipo_de_vehiculo;
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String Placa) {
        this.Placa = Placa;
    }
    public String getModelo() {
        return Modelo;
    }
    
     public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }
}
