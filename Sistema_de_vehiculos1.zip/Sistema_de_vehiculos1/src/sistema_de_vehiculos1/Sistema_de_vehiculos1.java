
package sistema_de_vehiculos1;

import modelo.Vehiculos;
import modelo.ConsultaVehiculos;
import vista.frmVehiculos;
import controlador.CtrlVehiculos;

public class Sistema_de_vehiculos1 {

    public static void main(String[] args) {
Vehiculos mod = new Vehiculos();
    ConsultaVehiculos modC = new ConsultaVehiculos();
    frmVehiculos frm = new frmVehiculos();
    
    CtrlVehiculos ctrl = new CtrlVehiculos(mod, modC, frm);
    ctrl.iniciar();
    frm.setVisible(true);
    }
    
}
