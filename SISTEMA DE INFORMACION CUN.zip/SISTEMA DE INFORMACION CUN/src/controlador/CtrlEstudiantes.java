
package controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.Consultaestudiantes;
import modelo.Estudiantes;
import vista.frmEstudiantes;

public class CtrlEstudiantes implements ActionListener {
    private Estudiantes mod;
    private Consultaestudiantes modC;
    private frmEstudiantes frm;
    
    public CtrlEstudiantes(Estudiantes mod, Consultaestudiantes modC, frmEstudiantes frm){
        this.mod = mod;
        this.modC = modC;
        this.frm = frm;
        this.frm.btnGuardar.addActionListener(this);
    }
   public void iniciar() {
    frm.setTitle("Estudiantes");
    frm.setLocationRelativeTo(null);
}
   @Override
   public void actionPerformed(ActionEvent e){
       if (e.getSource() == frm.btnGuardar){
           mod.setCodigo(frm.textCodigo.getText());
           mod.setApellidos(frm.textApellidos.getText());
           mod.setCargo(frm.textCargo.getText());
           
           if(modC.registrar(mod))
           {
               JOptionPane.showMessageDialog(null, "registro guardado");
           }else{
               JOptionPane.showMessageDialog(null, "No guardado");
           }
       }
   }
   
}
