
package sistema.de.informacion.cun;

import modelo.Estudiantes;
import modelo.Consultaestudiantes;
import vista.frmEstudiantes;
import controlador.CtrlEstudiantes;

public class SISTEMADEINFORMACIONCUN {

    public static void main(String[] args) {
    Estudiantes mod = new Estudiantes();
    Consultaestudiantes modC = new Consultaestudiantes();
    frmEstudiantes frm = new frmEstudiantes();
    
    CtrlEstudiantes ctrl = new CtrlEstudiantes(mod, modC, frm);
    ctrl.iniciar();
    frm.setVisible(true);
    }
    
}
